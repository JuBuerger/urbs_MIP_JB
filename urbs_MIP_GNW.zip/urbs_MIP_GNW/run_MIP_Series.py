# -*- coding: utf-8 -*-
import os
import shutil
import urbs
from pathlib import Path
from urbs.runfunctions import *

aaaa=os.listdir('Input/Simulation')
for xyzxyz in range(0,len(aaaa)-1):
    #input_files = 'input_urbs_40_CO2_0_OIL_CB.xlsx'  # for single year file name, for intertemporal folder name
    input_files = aaaa[xyzxyz]

    input_dir = 'Input/Simulation'
    input_path = os.path.join(input_dir, input_files)

    microgrid_files = ['Microgrid_rural_A.xlsx','Microgrid_urban_A.xlsx']
    microgrid_dir = 'Input/microgrid_types'
    microgrid_paths = []
    for i, microgrid_file in enumerate(microgrid_files):
        microgrid_paths.append(os.path.join(microgrid_dir, microgrid_file))

    result_name = 'GNW_optim'
    result_dir = urbs.prepare_result_directory(result_name)  

# #copy input file to result directory
    try:
        shutil.copytree(input_path, os.path.join(result_dir, input_dir))
    except NotADirectoryError:
        shutil.copyfile(input_path, os.path.join(result_dir, input_files))

# #copy run file to result directory
    shutil.copy(__file__, result_dir)

# objective function
    objective = 'cost'  # set either 'cost' or 'CO2' as objective
#objective = 'CO2'  # set either 'cost' or 'CO2' as objective

# Choose Solver (cplex, glpk, gurobi, ...)
    solver = 'gurobi'

# input data for tsam method
#noTypicalPeriods = 4
#hoursPerPeriod = 8760

# simulation timesteps
    (offset, length) = (0,8760)  # time step selection
    timesteps = range(offset, offset+length+1)
    dt = 1  # length of each time step (unit: hours)

# detailed reporting commodity/sites
    report_tuples = []
    import pandas as pd
    import glob
    if os.path.isdir(input_path):
        glob_input = os.path.join(input_path, '*.xlsx')
        input_files = sorted(glob.glob(glob_input))
    else:
        input_files = [input_path]
    for filename in input_files:
        print("reading started")
        with pd.ExcelFile(filename) as xls:
            site = xls.parse('Site').set_index(['Name'])
            print("reading complete")


    report_tuples =           [(2022, sit, 'Heat') for sit in site.index]+[(2022, sit, 'Heat_s') for sit in site.index]+[(2022, sit, 'Elec') for sit in site.index]+ [(2022, sit, 'common_heat') for sit in site.index if sit[0:4] == 'load']

# optional: define names for sites in report_tuples
    report_sites_name = {}
# plotting commodities/sites
    plot_tuples = []
# optional: define names for sites in plot_tuples
    plot_sites_name = {}

# plotting timesteps
    plot_periods = {
        'all': timesteps[1:]
        }
#time_series_for_aggregation = {'demand': ['electricity', ']}
# select scenarios to be run
    scenarios = [
                 urbs.flex_all         
                 ]


    cross_scenario_data = dict()
    for scenario in scenarios:
        prob, cross_scenario_data = urbs.run_scenario(input_path, solver, timesteps, scenario,
                                                      result_dir, dt, objective, microgrid_paths,
                                                      plot_tuples=plot_tuples,
                                                      plot_sites_name=plot_sites_name,
                                                      plot_periods=plot_periods,
                                                      report_tuples=report_tuples,
                                                      cross_scenario_data = cross_scenario_data,
                                                      report_sites_name=report_sites_name,
                                                      #noTypicalPeriods=noTypicalPeriods,
                                                      #hoursPerPeriod=hoursPerPeriod
                            )